import gradio as gr
import re
import os

# ============================================================
# 1. SAMPLE DOG DATABASE
# ============================================================

dogs = [
    {
        "name": "Buddy", "age": "2 years",
        "breed": "Golden Retriever Mix", "size": "Large",
        "energy": "High", "exercise": 90,
        "kids": "Yes", "pets": "Good", "alone": 5,
        "experience": "Beginner",
        "personality": "Friendly, playful, and affectionate.",
        "needs": "Daily walks, outdoor activities, and playtime."
    },
    {
        "name": "Luna", "age": "4 years",
        "breed": "Beagle Mix", "size": "Medium",
        "energy": "Moderate", "exercise": 45,
        "kids": "Yes", "pets": "Slow introduction", "alone": 6,
        "experience": "Beginner",
        "personality": "Gentle, curious, and loving.",
        "needs": "Regular walks and opportunities to explore."
    },
    {
        "name": "Max", "age": "3 years",
        "breed": "Border Collie Mix", "size": "Medium",
        "energy": "High", "exercise": 120,
        "kids": "Yes", "pets": "Slow introduction", "alone": 3,
        "experience": "Experienced",
        "personality": "Intelligent, energetic, and adventurous.",
        "needs": "Extensive exercise and mental stimulation."
    },
    {
        "name": "Daisy", "age": "6 years",
        "breed": "Cavalier Spaniel Mix", "size": "Small",
        "energy": "Low", "exercise": 30,
        "kids": "Yes", "pets": "Good", "alone": 7,
        "experience": "Beginner",
        "personality": "Calm, affectionate, and easygoing.",
        "needs": "Short walks and a comfortable home."
    },
    {
        "name": "Rocky", "age": "5 years",
        "breed": "Labrador Mix", "size": "Large",
        "energy": "Moderate", "exercise": 60,
        "kids": "No", "pets": "No", "alone": 5,
        "experience": "Experienced",
        "personality": "Loyal, independent, and playful.",
        "needs": "Daily exercise and a pet-free household."
    },
    {
        "name": "Coco", "age": "1 year",
        "breed": "Poodle Mix", "size": "Small",
        "energy": "Moderate", "exercise": 45,
        "kids": "Yes", "pets": "Good", "alone": 3,
        "experience": "Beginner",
        "personality": "Social, cheerful, and affectionate.",
        "needs": "Daily playtime, training, and companionship."
    }
]

# ============================================================
# 2. QUESTIONS
# ============================================================

questions = [
    ("children", "Do you have children at home? Answer Yes or No."),
    ("pets", "Do you have other pets? Answer Yes or No."),
    ("activity", "What is your activity level? Low, Moderate, or High?"),
    ("exercise", "How many minutes per day can you exercise your dog?"),
    ("alone", "How many hours will your dog be home alone each day?"),
    ("experience", "Are you a Beginner or Experienced dog owner?")
]

# ============================================================
# 3. ANSWER PROCESSING
# ============================================================

def get_number(text):
    match = re.search(r"\d+", text)
    return int(match.group()) if match else None


def process_answer(key, answer):
    answer = answer.lower().strip()
    if key == "children":
        if answer in ["yes", "y"]:
            return True
        if answer in ["no", "n"]:
            return False
    elif key == "pets":
        if answer in ["no", "n", "none", "no pets"]:
            return False
        if answer in ["yes", "y"] or any(
            pet in answer for pet in ["cat", "dog", "bird", "rabbit"]
        ):
            return True
    elif key == "activity":
        if "high" in answer:
            return "High"
        if "moderate" in answer or "medium" in answer:
            return "Moderate"
        if "low" in answer:
            return "Low"
    elif key in ["exercise", "alone"]:
        number = get_number(answer)
        maximum = 1440 if key == "exercise" else 24
        if number is not None and 0 <= number <= maximum:
            return number
    elif key == "experience":
        if "beginner" in answer or "first" in answer:
            return "Beginner"
        if "experienced" in answer or answer in ["yes", "y"]:
            return "Experienced"
    return None

# ============================================================
# 4. MATCHING SYSTEM
# ============================================================

def calculate_match(dog, profile):
    score = 0
    reasons = []
    concerns = []

    if dog["energy"] == profile["activity"]:
        score += 20
        reasons.append("Your activity levels are compatible.")
    elif dog["energy"] == "Moderate" or profile["activity"] == "Moderate":
        score += 12
        reasons.append("The dog's activity needs may fit your routine.")
    else:
        score += 5
        concerns.append("The dog's energy level may differ from yours.")

    if profile["exercise"] >= dog["exercise"]:
        score += 20
        reasons.append("You can provide the dog's estimated exercise time.")
    elif profile["exercise"] >= dog["exercise"] * 0.7:
        score += 10
        concerns.append("You may need additional time for exercise.")
    else:
        concerns.append("The dog needs more exercise than you currently have time for.")

    if profile["children"]:
        if dog["kids"] == "Yes":
            score += 20
            reasons.append("The shelter reports compatibility with children.")
        else:
            concerns.append("The shelter has not listed this dog as suitable for children.")
    else:
        score += 20

    if profile["pets"]:
        if dog["pets"] == "Good":
            score += 20
            reasons.append("The dog is reported to be compatible with other pets.")
        elif dog["pets"] == "Slow introduction":
            score += 10
            concerns.append("A gradual introduction to other pets is recommended.")
        else:
            concerns.append("The shelter does not recommend this dog for homes with other pets.")
    else:
        score += 20

    if profile["alone"] <= dog["alone"]:
        score += 10
        reasons.append("Your schedule fits the dog's reported alone-time estimate.")
    else:
        concerns.append("Additional daytime companionship may be necessary.")

    if dog["experience"] == "Beginner":
        score += 10
        reasons.append("This dog is listed as potentially suitable for beginners.")
    elif profile["experience"] == "Experienced":
        score += 10
        reasons.append("Your experience may help meet this dog's needs.")
    else:
        concerns.append("This dog may benefit from an experienced owner.")

    eligible = not (
        (profile["children"] and dog["kids"] != "Yes")
        or (profile["pets"] and dog["pets"] == "No")
    )
    return score, reasons, concerns, eligible

# ============================================================
# 5. RECOMMENDATIONS
# ============================================================

def recommend_dogs(profile):
    results = []
    for dog in dogs:
        score, reasons, concerns, eligible = calculate_match(dog, profile)
        if eligible:
            results.append((score, dog, reasons, concerns))
    results.sort(key=lambda x: x[0], reverse=True)
    if not results:
        return """\n## 🐾 No suitable matches found yet.\n\nPlease contact a local shelter or rescue to discuss\ndogs whose individual needs may fit your household.\n"""

    output = "## 🐾 Your Fetch Us Dog Matches!\n\n"
    for i, (score, dog, reasons, concerns) in enumerate(results[:3], 1):
        output += f"""\n### {i}. {dog['name']} — {score}% Match\n\n- **Breed:** {dog['breed']}\n- **Age:** {dog['age']}\n- **Size:** {dog['size']}\n- **Energy:** {dog['energy']}\n- **Exercise:** {dog['exercise']} minutes daily\n\n**Personality:** {dog['personality']}\n\n**Why this dog may fit your life:**\n"""
        for reason in reasons:
            output += f"- {reason}\n"
        if concerns:
            output += "\n**Things to consider:**\n"
            for concern in concerns:
                output += f"- {concern}\n"
        output += f"\n**Special needs:** {dog['needs']}\n\n---\n"

    output += """\n### ❤️ A Reminder from Fetch Us\n\nMatch scores are estimates, not guarantees.\nPlease confirm behavior, medical history, and compatibility\nwith the shelter before adopting.\n\nMeet the dog before making your final decision!\n"""
    return output

# ============================================================
# 6. CHATBOT
# ============================================================

def chatbot(message, history, profile, step):
    history = history or []
    profile = profile or {}
    message = message.strip()
    if not message:
        return history, profile, step, ""
    history.append({"role": "user", "content": message})

    if message.lower() in ["restart", "reset", "start over"]:
        profile = {}
        step = 0
        history.append({
            "role": "assistant",
            "content": "Welcome back to Fetch Us! 🐶\n\n" + questions[0][1]
        })
        return history, profile, step, ""

    if step >= len(questions):
        history.append({
            "role": "assistant",
            "content": "Your recommendations are above! Type restart to search again."
        })
        return history, profile, step, ""

    key = questions[step][0]
    value = process_answer(key, message)
    if value is None:
        prompts = {
            "children": "Please answer Yes or No.",
            "pets": "Please answer Yes or No, or describe your pets.",
            "activity": "Please answer Low, Moderate, or High.",
            "exercise": "Please enter the number of minutes per day.",
            "alone": "Please enter the number of hours per day.",
            "experience": "Please answer Beginner or Experienced."
        }
        reply = prompts[key]
    else:
        profile[key] = value
        step += 1
        if step < len(questions):
            reply = questions[step][1]
        else:
            reply = (
                "Thank you! ❤️ I'm finding your potential matches.\n\n"
                + recommend_dogs(profile)
                + "\n\nType **restart** to begin another search."
            )
    history.append({"role": "assistant", "content": reply})
    return history, profile, step, ""

# ============================================================
# 7. GRADIO INTERFACE
# ============================================================

with gr.Blocks(title="Fetch Us - Dog Adoption Assistant") as demo:
    gr.Markdown("""
    # 🐾 FETCH US
    ### Find a dog that fits your life, not just your eyes.

    Welcome to Fetch Us! ❤️

    I'm your virtual dog adoption assistant.
    Answer a few questions about your lifestyle,
    schedule, and household to find your potential match.

    **Let's find your new best friend!**
    """)

    chat = gr.Chatbot(
        value=[{
            "role": "assistant",
            "content": "Hi! Welcome to Fetch Us! 🐶\n\n" + questions[0][1]
        }],
        height=450
    )

    profile_state = gr.State({})
    step_state = gr.State(0)

    with gr.Row():
        message = gr.Textbox(
            placeholder="Type your answer here...",
            show_label=False,
            scale=5
        )
        send = gr.Button("Send 🐾", variant="primary")

    gr.Markdown(
        "*Type restart at any time to begin a new search. "
        "Always confirm adoption information with the shelter.*"
    )

    inputs = [message, chat, profile_state, step_state]
    outputs = [chat, profile_state, step_state, message]

    send.click(chatbot, inputs=inputs, outputs=outputs)
    message.submit(chatbot, inputs=inputs, outputs=outputs)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=int(os.environ.get("PORT", 10000)))