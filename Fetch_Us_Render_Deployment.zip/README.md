# Fetch Us — Gradio Dog Adoption Assistant

## Deploy on Render (free web service)

1. Create a GitHub repository and upload `app.py` and `requirements.txt`.
2. In Render, choose **New → Web Service**.
3. Connect the GitHub repository.
4. Use these settings:
   - **Runtime:** Python 3
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `python app.py`
   - **Instance type:** Free
5. Click **Create Web Service** and wait for deployment.
6. Render will provide a public `onrender.com` URL.

The app is configured to listen on Render's assigned `PORT`.

## Important
The free Render service sleeps after 15 minutes without traffic. The public URL remains the same, but the first visit after sleeping can take about a minute to load.
